function err = tfocs_err() 
%  tfocs_err : TFOCS error measurement
%
%   $Revision: 0.1.2 $  $Date: 2012/09/15 $
% 
  global subprob_optim
  
  err = subprob_optim;
  